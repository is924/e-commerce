import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-YNH7ZZW7.js";
import "./chunk-MLXUHDRH.js";
import "./chunk-NSNFIM63.js";
import "./chunk-SD5VBNF2.js";
import "./chunk-CCXG4OVJ.js";
import "./chunk-SEK7UKQV.js";
import "./chunk-6DU2HRTW.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
