import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';


// Routing
import { AppRoutingModule } from './app-routing-module';

// Root component
import { App } from './app';

// Components
import { Sidebar } from './components/sidebar/sidebar';
import { Topbar } from './components/top-bar/top-bar';
import { LoginComponent } from './pages/login/login';
import { HomeComponent } from './pages/home/home';
import { OrdersComponent } from './pages/orders/orders';
import { UsersComponent } from './pages/users/users';
import { ProductsComponent } from './pages/products/products';
import { ReviewsComponent } from './pages/reviews/reviews';

// Dialogs (non-standalone)
import { ProductDialog } from './pages/products/product-dialog/product-dialog';
import { UserDialog } from './pages/users/user-dialog/user-dialog';
import { OrdersDialogComponent } from './pages/orders/orders-dialog/orders-dialog';

// Angular Material Modules
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';

//import { ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    App,
    Sidebar,
    Topbar,
    LoginComponent,
    HomeComponent,
    
    UsersComponent,
    ProductsComponent,
    ReviewsComponent,
    ProductDialog,
    UserDialog,
    OrdersDialogComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    MatToolbarModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatPaginatorModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    MatDialogModule,
    MatSelectModule,
    MatTooltipModule,
    ReactiveFormsModule,
    OrdersComponent,
    
  ],
  providers: [],
  bootstrap: [App]
})
export class AppModule { }