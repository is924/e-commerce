import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { ProjectService } from '../../projectservice/projectservice';
import { MatDialog } from '@angular/material/dialog';
import { UserDialog } from './user-dialog/user-dialog'; 

export interface User {
  userId: number;
  username: string;
  email: string;
  accountType: string;
}

@Component({
  selector: 'app-users',
  templateUrl: './users.html',
  styleUrls: ['./users.css'],
  standalone: false,
})
export class UsersComponent implements OnInit, AfterViewInit {
  users: User[] = [];
  displayedColumns: string[] = ['userId', 'username', 'email', 'accountType', 'actions'];
  dataSource = new MatTableDataSource<User>([]);
  total = 0;
  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25, 50];
  currentSearch = '';
  currentSort: Sort = { active: 'userId', direction: 'asc' };
  loading = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private projectService: ProjectService, private dialog: MatDialog) {}

  ngOnInit() {
    this.fetchUsers();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

 fetchUsers() {
  this.loading = true;
  this.projectService.getusers().subscribe(
    (data) => {
      this.users = data.map(u => ({
        userId: u.userId!,   
        username: u.username,
        email: u.email,
        accountType: u.accountType
      }));
      this.dataSource.data = this.users;
      this.total = this.users.length;
      this.loading = false;
    },
    (error) => {
      console.error('Error fetching users:', error);
      this.loading = false;
    }
  );
}


  applyClientFilter(value: string): void {
    this.currentSearch = value;
    this.dataSource.filter = value.trim().toLowerCase();
    if (this.dataSource.paginator) this.dataSource.paginator.firstPage();
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }

  onSortChange(sort: Sort): void {
    this.currentSort = sort;
  }

  refresh(): void {
    this.fetchUsers();
  }

  trackByUserId = (_: number, item: User) => item.userId;

  // ----------------- CRUD Operations -----------------
  addUser(): void {
    const dialogRef = this.dialog.open(UserDialog, {
      width: '400px',
      data: { user: null }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.projectService.addUser(result)?.subscribe(() => this.fetchUsers());
      }
    });
  }

  editUser(user: User): void {
    const dialogRef = this.dialog.open(UserDialog, {
      width: '400px',
      data: { user }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // Assert that userId is not undefined
        this.projectService.updateUser(user.userId!, result)?.subscribe(() => this.fetchUsers());
      }
    });
  }

  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.projectService.deleteUser?.(userId)?.subscribe(() => this.fetchUsers());
    }
  }
}
