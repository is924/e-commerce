import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-user-dialog',
  templateUrl: './user-dialog.html',
  styleUrls: ['./user-dialog.css'],
  standalone: false,
})
export class UserDialog {
  user: any;

  constructor(
    public dialogRef: MatDialogRef<UserDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.user = data.user || {}; // Initialize with empty object if adding
  }

  save(): void {
    this.dialogRef.close(this.user); // Return data to parent
  }

  cancel(): void {
    this.dialogRef.close(); // Close without returning data
  }
}
