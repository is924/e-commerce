import { Component } from '@angular/core';

@Component({
  selector: 'app-reviews-dialog',
  standalone: false,
  templateUrl: './reviews-dialog.html',
  styleUrl: './reviews-dialog.css'
})
export class ReviewsDialog {

}
