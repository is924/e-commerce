import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewsDialog } from './reviews-dialog';

describe('ReviewsDialog', () => {
  let component: ReviewsDialog;
  let fixture: ComponentFixture<ReviewsDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReviewsDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReviewsDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
