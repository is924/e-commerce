import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { ProjectService } from '../../projectservice/projectservice';

export interface Review {
  reviewId: number;
  rating: number;
  comments: string;
  userId: number;
  productId: number;
}

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.html',
  styleUrls: ['./reviews.css'],
  standalone: false, 
})
export class ReviewsComponent implements OnInit, AfterViewInit {
  reviews: Review[] = [];
  displayedColumns: string[] = [
    'reviewId',
    'rating',
    'comments',
    'userId',
    'productId'
  ];
  dataSource = new MatTableDataSource<Review>([]);
  total = 0;
  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25, 50];
  currentSearch = '';
  currentSort: Sort = { active: 'reviewId', direction: 'asc' };
  loading = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private projectService: ProjectService) {}

  ngOnInit() {
    this.fetchReviews();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  fetchReviews() {
  this.loading = true;
  this.projectService.getReviews().subscribe(
    (data: any) => {
      this.reviews = data;
      this.dataSource = new MatTableDataSource<Review>(this.reviews);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
      this.total = this.reviews.length;
      setTimeout(() => this.loading = false); 
    },
    (error: any) => {
      console.error('Error fetching reviews:', error);
      setTimeout(() => this.loading = false); 
    }
  );
}


  applyClientFilter(value: string): void {
    this.currentSearch = value;
    this.dataSource.filter = value?.trim().toLowerCase();
    if (this.dataSource.paginator) this.dataSource.paginator.firstPage();
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.fetchReviews();
  }

  onSortChange(sort: Sort): void {
    this.currentSort = sort;
    this.fetchReviews();
  }

  refresh(): void {
    this.fetchReviews();
  }

  trackByReviewId = (_: number, item: Review) => item.reviewId;
}