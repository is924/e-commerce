import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { ProjectService, Product, User, Seller } from '../../projectservice/projectservice';
import { MatDialog } from '@angular/material/dialog';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-products',
  templateUrl: './products.html',
  styleUrls: ['./products.css'],
  standalone: false,
})
export class ProductsComponent implements OnInit, AfterViewInit {
  products: Product[] = [];
  displayedColumns: string[] = ['productId', 'name', 'description', 'price', 'quantityAvailable', 'seller', 'actions'];
  dataSource = new MatTableDataSource<Product>([]);
  total = 0;
  pageSize = 10;
  pageIndex = 0;
  pageSizeOptions = [5, 10, 25, 50];
  currentSearch = '';
  currentSort: Sort = { active: 'productId', direction: 'asc' };
  loading = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private projectService: ProjectService, private dialog: MatDialog) {}

  ngOnInit() {
    this.fetchProducts();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  fetchProducts() {
    this.loading = true;
    this.projectService.getProducts().subscribe(
      (data) => {
        this.products = data.map((p) => ({
          productId: p.productId,
          name: p.name,
          description: p.description,
          price: p.price,
          quantityAvailable: p.quantityAvailable,
          seller: p.seller
            ? {
                id: p.seller.id,
                user: p.seller.user,
                companyName: p.seller.companyName,
                contactInfo: p.seller.contactInfo,
                averageRating: p.seller.averageRating ?? 0
              }
            : {
                id: 0,
                user: {
                  userId: 0,
                  username: 'Unknown',
                  email: 'unknown@example.com',
                  accountType: 'UNKNOWN'
                },
                companyName: 'Unknown Seller',
                contactInfo: '',
                averageRating: 0
              }
        }));
        this.dataSource.data = this.products;
        this.total = this.products.length;
        this.loading = false;
      },
      (error) => {
        console.error('Error fetching products:', error);
        this.loading = false;
      }
    );
  }

  applyClientFilter(value: string): void {
    this.currentSearch = value;
    this.dataSource.filter = value.trim().toLowerCase();
    if (this.dataSource.paginator) this.dataSource.paginator.firstPage();
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
  }

  onSortChange(sort: Sort): void {
    this.currentSort = sort;
  }

  refresh(): void {
    this.fetchProducts();
  }

  trackByProductId = (_: number, item: Product) => item.productId;

  // ----------------- CRUD -----------------
  addProduct(): void {
    // TODO: open dialog like UserDialog for Product
  }

  editProduct(product: Product): void {
    // TODO: open dialog and update product
  }

  deleteProduct(productId: number): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.projectService.deleteProduct(productId).subscribe(() => this.fetchProducts());
    }
  }
}
