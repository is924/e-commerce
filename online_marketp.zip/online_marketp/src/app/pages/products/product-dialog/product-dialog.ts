import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Product, Seller, User } from '../../../projectservice/projectservice';

@Component({
  selector: 'app-product-dialog',
  templateUrl: './product-dialog.html',
  styleUrls: ['./product-dialog.css'],
  standalone: false,
})
export class ProductDialog {
  product: Partial<Product> & { sellerCompanyName?: string };

  constructor(
    public dialogRef: MatDialogRef<ProductDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { product: Product | null }
  ) {
    const sellerCompanyName = data.product?.seller?.companyName;
    this.product = {
      ...data.product,
      sellerCompanyName
    };
  }

  save(): void {
    const seller: Seller = {
      id: this.product.seller?.id || 0,
      companyName: this.product.sellerCompanyName || '',
      contactInfo: this.product.seller?.contactInfo || '',
      averageRating: this.product.seller?.averageRating || 0,
      user: this.product.seller?.user || {
        userId: 0,
        username: '',
        email: '',
        accountType: ''
      }
    };

    const finalProduct: Product = {
      productId: this.product.productId || 0,
      name: this.product.name || '',
      description: this.product.description || '',
      price: this.product.price || 0,
      quantityAvailable: this.product.quantityAvailable || 0,
      seller
    };

    this.dialogRef.close(finalProduct);
  }

  cancel(): void {
    this.dialogRef.close();
  }
}