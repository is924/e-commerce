import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

// Define your Order interface here to avoid duplicate imports
export interface Order {
  productId: number;
  userId: number;
  quantity: number;
  totalPrice: number;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'CANCELLED';
}

@Component({
  selector: 'app-orders-dialog',
  templateUrl: './orders-dialog.html',
  styleUrls: ['./orders-dialog.css'] ,
  standalone: false,
})

export class OrdersDialogComponent implements OnInit {
  orderForm!: FormGroup; // definite assignment

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<OrdersDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data?: Order
  ) {}

  ngOnInit(): void {
    this.orderForm = this.fb.group({
      productId: [this.data?.productId || '', Validators.required],
      userId: [this.data?.userId || '', Validators.required],
      quantity: [this.data?.quantity || 1, [Validators.required, Validators.min(1)]],
      totalPrice: [this.data?.totalPrice || 0, [Validators.required, Validators.min(0)]],
      status: [this.data?.status || 'PENDING', Validators.required]
    });
  }

  save(): void {
    if (this.orderForm.valid) {
      const order: Order = this.orderForm.value;
      this.dialogRef.close(order);
    }
  }

  cancel(): void {
    this.dialogRef.close();
  }
}

