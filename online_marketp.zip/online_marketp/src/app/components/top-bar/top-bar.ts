import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.html',
  styleUrls: ['./top-bar.css'],
  standalone: false,
})
export class Topbar {
  isLoggedIn = false;

  logout() {
    this.isLoggedIn = false;
  }
}
